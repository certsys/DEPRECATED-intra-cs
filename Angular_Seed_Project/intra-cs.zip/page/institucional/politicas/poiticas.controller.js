function politicas($scope, $http, contactService, userService, $state) {}

angular
    .module('inspinia')
    .controller('politicas', politicas);