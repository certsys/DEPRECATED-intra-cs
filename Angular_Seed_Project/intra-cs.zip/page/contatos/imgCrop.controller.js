
function imageCrop($scope) {
}


angular
    .module('inspinia')
    .controller('imageCrop', imageCrop);